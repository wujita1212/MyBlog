/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50528
Source Host           : localhost:3307
Source Database       : blog2

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2020-09-18 00:50:38
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `hibernate_sequence`
-- ----------------------------
DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hibernate_sequence
-- ----------------------------
INSERT INTO hibernate_sequence VALUES ('23');
INSERT INTO hibernate_sequence VALUES ('23');
INSERT INTO hibernate_sequence VALUES ('23');
INSERT INTO hibernate_sequence VALUES ('23');
INSERT INTO hibernate_sequence VALUES ('23');

-- ----------------------------
-- Table structure for `t_blog`
-- ----------------------------
DROP TABLE IF EXISTS `t_blog`;
CREATE TABLE `t_blog` (
  `id` bigint(20) NOT NULL,
  `appreciation` bit(1) NOT NULL,
  `commentable` bit(1) NOT NULL,
  `content` longtext,
  `create_time` datetime DEFAULT NULL,
  `flag` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `published` bit(1) NOT NULL,
  `recommend` bit(1) NOT NULL,
  `share_statement` bit(1) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKm6k0c9te0ya8npu78aaklyg7o` (`category_id`),
  KEY `FK8ky5rrsxh01nkhctmo7d48p82` (`user_id`),
  CONSTRAINT `FK8ky5rrsxh01nkhctmo7d48p82` FOREIGN KEY (`user_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FKm6k0c9te0ya8npu78aaklyg7o` FOREIGN KEY (`category_id`) REFERENCES `t_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_blog
-- ----------------------------
INSERT INTO t_blog VALUES ('8', '', '', '谁都会在无意之间失去什么\r\n猛然觉醒方知你已不在 徒留回忆\r\n惊慌失措间\r\n恍如丧却言语的人偶\r\n好似遗弃街角的猫咪\r\n失了声般听不见呼喊\r\n如果还能再次与你相会\r\n只想对你说一声\r\n谢谢 谢谢你\r\n\r\n有时即使会有伤害\r\n仍想感知你的存在\r\n至少回忆能安慰我\r\n你一直都在这里\r\n如果还能再次与你相会\r\n只想对你说一声\r\n谢谢 谢谢你\r\n\r\n如果还能再次与你相会\r\n只想对你说一声\r\n如果还能再次与你相会\r\n只想对你说一声\r\n谢谢 谢谢你\r\n\r\n有时即使会有伤害\r\n仍想感知你的存在\r\n\r\n\r\n原文：ありがとう\r\n\r\n谁もが気づかぬうちに\r\n何かを失っている\r\nフッと気づけばあなたはいない\r\n思い出だけを残して\r\nせわしい时の中\r\n言叶を失った人形达のように\r\n街角に溢れたノラネコのように\r\n声にならない叫びが闻こえてくる\r\nもしも もう一度あなたに会えるなら\r\nたった一言伝えたい\r\nありがと ありがとう\r\n时には伤つけあっても\r\nあなたを感じていたい\r\n思いではせめてもの慰め\r\nいつまでもあなたはここにいる\r\nもしも もう一度あなたに会えるなら\r\nたった一言伝えたい\r\nありがと ありがとう\r\nもしも もう一度あなたに会えるなら\r\nたった一言伝えたい\r\nもしも もう一度あなたに会えるなら\r\nたった一言伝えたい\r\nありがと ありがとう\r\n时には伤つけあっても\r\nあなたを感じていたい', '2020-09-16 21:15:01', 'Translation', 'https://unsplash.it/800/450?image=1005', '', '', '', 'ありがとう', '2020-09-17 01:29:34', '0', '12', '1', '如果还能再次与你相会\r\n只想对你说一声\r\n如果还能再次与你相会\r\n只想对你说一声\r\n谢谢 谢谢你');
INSERT INTO t_blog VALUES ('11', '', '', 'How much more do I have to lose, before my heart is forgiven?\r\nHow many more pains do I have to suffer, to meet you once again?\r\nOne more time, oh seasons, fade not\r\nOne more time, when we were messing around\r\n \r\nWhenever we disagreed, I would always give in first\r\nYour selfish nature made me love you even more\r\nOne more chance, the memories restrain my steps\r\nOne more chance, I cannot choose my next destination\r\n \r\nI\'m always searching, for your figure to appear somewhere\r\nOn the opposite platform, in the windows along the lane\r\nEven though I know you couldn\'t be at such a place\r\nIf my wish were to come true, I would be at your side right away\r\nThere would be nothing I couldn\'t do\r\n \r\nI would put everything on the line and hold you tight\r\nIf I just wanted to avoid loneliness, anybody would have been enough.\r\nBecause the night looks like the stars will fall, I cannot lie to myself.\r\nOne more time, oh seasons, fade not.\r\nOne more time, when we were messing around\r\n \r\nI\'m always searching, for your figure to appear somewhere\r\nAt a street crossing, in the midst of dreams\r\nEven though I know you couldn\'t be at such a place\r\nIf a miracle were to happen here, I would show you right away\r\nThe new morning, who I\'ll be from now on\r\nAnd the words I never said: \"I love you.\"\r\n \r\nThe memories of summer are revolving\r\nThe throbbing which suddenly disappeared\r\n \r\nI\'m always searching, for your figure to appear somewhere\r\nAt dawn on the streets, at Sakuragi-cho\r\nEven though I know you couldn\'t be at such a place\r\nIf my wish were to come true, I would be at your side right away\r\nThere would be nothing I couldn\'t do\r\nI would put everything on the line and hold you tight\r\n \r\nI\'m always searching, for fragments of you to appear somewhere\r\nAt a traveller\'s store, in the corner of newspaper,\r\nEven though I know you couldn\'t be at such a place\r\nIf a miracle were to happen here, I would show you right away\r\nThe new morning, who I\'ll be from now on\r\nAnd the words I never said: \"I love you.\"\r\n \r\nI always end up looking for your smile, to appear somewhere\r\nAt the railroad crossing, waiting for the express to pass\r\nEven though I know you couldn\'t be at such a place\r\nIf our lives could be repeated, I would be at your side every time\r\nI would want nothing else\r\nNothing else is more important than you…', '2020-09-16 21:29:50', 'Translation', 'https://unsplash.it/800/450?image=1005', '', '', '', 'One more time, one more chance', '2020-09-17 21:55:53', '1', '12', '1', 'If our lives could be repeated, I would be at your side every time\r\nI would want nothing else\r\nNothing else is more important than you…');
INSERT INTO t_blog VALUES ('13', '', '', 'For years, functional programming has been considered the realm of a small band of specialists who consistently claimed superiority to the masses while being unable to spread the wisdom of their approach. The main reason I’ve written this book is to challenge both the idea that there’s an innate superiority in the functional style and the belief that its approach should be relegated to a small band of specialists!\r\n\r\nFor the last two years in the London Java Community, I’ve been getting developers to try out Java 8 in some form or another. I’ve found that many of our members enjoy the new idioms and libraries that it makes available to them. They may reel at the terminology\r\nand elitism, but they love the benefits that a bit of simple functional programming provides to them. A common thread is how much easier it is to read code using the new Streams API to manipulate objects and collections, such as filtering out albums that were made in the UK from a List of all albums.\r\n\r\nWhat I’ve learned when running these kinds of events is that examples matter. People learn by repeatedly digesting simple examples and developing an understanding of patterns out of them. I’ve also noticed that terminology can be very off-putting, so anytime there’s a hard-sounding concept, I give an easy-to-read explanation.\r\n\r\nFor many people, what Java 8 offers by way of functional programming is incredibly limited: no monads,1 no language-level lazy evaluation, no additional support for immutability.\r\n\r\nAs pragmatic programmers, this is fine; what we want is the ability to write library-level abstractions so we can write simple, clean code that solves business problems.\r\n\r\nWe’re even happier if someone else has written these libraries for us and we can just focus on doing our daily jobs.\r\n', '2020-09-17 13:22:18', 'Reprint', 'https://unsplash.it/800/450?image=227', '', '', '', 'Java8 - preface', '2020-09-17 13:22:51', '0', '2', '1', 'For many people, what Java 8 offers by way of functional programming is incredibly limited: no monads,1 no language-level lazy evaluation, no additional support for immutability.');
INSERT INTO t_blog VALUES ('15', '', '', 'DALL’INVIATO A BRUXELLES.\r\n\r\nL’Europa travolta dalla pandemia si è riscoperta «fragile». E la persistenza del virus «aumenta l’incertezza» che frena la ripresa. Per questo motivo Ursula von der Leyen assicura che «non è il momento di ritirare il sostegno all’economia». Tradotto: le regole del Patto di Stabilità resteranno sospese ancora a lungo perché – per portare l’Ue verso «una nuova vitalità» – bisogna continuare con le politiche di bilancio espansive. Ma al tempo stesso «bisogna trovare un delicato equilibrio tra il sostegno finanziario e la sostenibilità dei bilanci pubblici». Servono investimenti massicci, specialmente nei progetti eco-sostenibili e nella transizione digitale, ma «bisogna usare questa opportunità per fare le riforme strutturali». Ecco le direttrici lungo le quali dovranno muoversi i governi nei loro Recovery Plan nazionali.', '2020-09-17 13:26:09', 'Reprint', 'https://unsplash.it/800/450?image=227', '', '', '', 'Clima', '2020-09-17 13:35:48', '0', '3', '1', 'L’Europa travolta dalla pandemia si è riscoperta «fragile». E la persistenza del virus «aumenta l’incertezza» che frena la ripresa. ');
INSERT INTO t_blog VALUES ('16', '', '', 'Italiani pronti a farsi impiantare nel proprio corpo sistemi hi-tech per potenziare le capacità fisiche, migliorare il proprio aspetto fisico, \"cancellare\" difetti come problemi di vista e per interagire in maniera più profonda con l\'ambiente che li circonda. Questo dato emerge da una ricerca commissionata dalla società di sicurezza informatica, Kaspersky e condotta su 14500 utenti in 16 paesi dell\'Europa e del Nord Africa, Italia naturalmente compresa. C\'è un entusiasmo diffuso - spiega la ricerca  - per la \"human augmentation\", ovvero il processo che consente di potenziare e migliorare il corpo umano sfruttando la tecnologia. Il 92% delle persone intervistate cambierebbe un aspetto del proprio fisico se potesse, mentre quasi due terzi (63%) prenderebbe in considerazione la possibilità di potenziare il proprio corpo con la tecnologia per migliorarlo in modo permanente o temporaneo. Gli italiani appaiono come quelli più propensi a considerare possibile e utilizzabile la human augmentation (81%), mentre gli inglesi sono i meno convinti, con solo il 33% di intervistati che si è dimostrato interessato al potenziamento del proprio corpo. Alcune delle persone intervistate ha addirittura espresso il desiderio di collegare lo smartphone al proprio corpo.\r\n\r\nPer la maggior parte degli intervistati questa tecnologia è da considerarsi solo se utilizzata per il bene dell\'umanità, mentre per il 53% solo nel caso in cui serva a migliorare la qualità della vita. In generale, in ogni Paese coinvolto dall\'indagine, l\'obiettivo della human augmentation deve essere soprattutto quello di migliorare la salute fisica in generale (40%) o la vista (33%). Permangono tuttavia alcuni dubbi. Il 69% degli intervistati ha dichiarato di temere che questa possibilità venga limitata esclusivamente ai ricchi (69%), mentre quasi nove persone su dieci (88%) ha dichiarato di temere che il corpo \"potenziato\" possa diventare bersaglio dei cyber criminali.\r\n\r\nSe un tempo il concetto di human augmentation, ovvero il processo di ricreare o migliorare le nostre capacità fisiche e mentali, era esclusivo appannaggio della fantascienza, oggi si sta dimostrando sempre più vicino alla realtà, poiché la tecnologia sta diventando una parte sempre più importante della nostra vita quotidiana. Marco Preuss, Director of the Global Research & Analysis Team, Europe, di Kaspersky, spiega:  \"La human augmentation è uno dei trend tecnologici più significativi del mondo moderno. Stiamo già assistendo a un\'ampia gamma di applicazioni pratiche in tutti i settori della nostra vita quotidiana, come la sanità e l\'assistenza sociale, lo sport, l\'istruzione e i trasporti. Gli esoscheletri per gli incendi e i soccorsi o la biostampa di organi sono solo alcuni esempi. Ma le persone hanno ragione ad essere prudenti. Gli appassionati dell\'augmentation stanno già testando i limiti di questa opportunità. È necessario infatti concordare degli standard per garantire che l\'augmentation raggiunga il suo pieno potenziale minimizzando i rischi\".\r\n\r\nGli adulti intervistati che vivono nell\'Europa meridionale tra cui Spagna, Portogallo, Grecia e Italia, insieme al Marocco, sono tra i più aperti alla human augmentation.Gli adulti intervistati nel Regno Unito e in Francia sembrano essere, invece, i più scettici con il 36% degli inglesi e il 30% dei francesi contrari a questa tendenza. Più della metà degli adulti in Francia (53%) e nel Regno Unito (52%) ritiene che la human augmentation potrebbe essere pericolosa per la società. Si tratta di percentuali che vanno ben oltre la media di tutti gli intervistati (39%).\r\n\r\nPotenziare il corpo per renderlo più attraente ha sedotto più di un terzo (36%) delle donne e solo un quarto (25%) degli uomini. Gli uomini si sono dimostrati più interessati a potenziare la loro forza con il 23% rispetto al 18% delle donne. Quasi la metà (47%) degli intervistati ritiene che i governi dovrebbero regolamentare la human augmentation. Il Regno Unito è il più favorevole all\'intervento del governo (77%) al contrario della Grecia che sembra meno convinta con il 17%. Un terzo delle persone (33%) è \"entusiasta\" all\'idea che esista la human augmentation, anche se le donne (21%) si sono dimostrate più preoccupate che entusiaste rispetto agli uomini (15%).\r\n\r\n\"Sono convinto che la maggior parte delle persone sarà disposta ad accettare il potenziamento del proprio corpo, purché si tratti di piccoli passi e purché ci siano dei benefici economici e medici che ne derivano\", ha commentato Zoltan Istvan, autore e fondatore di The Transhumanist Party. \"Storicamente le persone si sono sempre dimostrate poco propense alle innovazioni tecnologiche soprattutto quando queste sono ancora poco conosciute, ma poi si finisce sempre per accettarle perché ci si rende conto che ne va del loro lavoro, del loro sostentamento e della sicurezza nazionale\".', '2020-09-17 13:28:28', 'Reprint', 'https://unsplash.it/800/450?image=227', '', '', '', 'Italiani popolo di futuri cyborg. Pronti a integrare l\'hi-tech con il corpo', '2020-09-17 13:28:54', '0', '3', '1', '\"Sono convinto che la maggior parte delle persone sarà disposta ad accettare il potenziamento del proprio corpo, purché si tratti di piccoli passi e purché ci siano dei benefici economici e medici che');
INSERT INTO t_blog VALUES ('18', '', '', '今の私なら言える、たとえあの結果が最初から分かっていても、<br>\r\n时间が逆に流れる事を出来る限り、何度も私はあなたの事を好きになるだろう。<br>\r\nしかし、それはあくまで、十五歳の私だけ持った気持ちです。<br>\r\n人は変われる。<br>\r\nあれから、もう何年を経った。人や物も環境も一度分けれてぞれぞれの道に歩き続けると、誰でも、もうあの原点には戻れない。<br>\r\n\r\n確かに、人の根はそう簡単には変わらないと思う。<br>\r\nでも、心というのは、ただの性格、価値観、家庭環境とか積み重ねた物ではない。<br>\r\n周りの環境、隣の友人、同士、そしていろんな事を会って経験した後合わせ集める物です。<br>\r\n一度だけでも、完全に離れ離れの人達にして、<br>\r\n同じ経験を味会わない限り、人生の行方もそうやってだんだん遠くになるだろう。<br>\r\nそれは別に悲しいことではありません。<br>\r\nなぜなら、それを理解出来る人間こそ、もっと堅実に今自分が選んだ道に前に進め出来る。<br>\r\n\r\nそういっても、私は別に人は二度と同一人物のことを好きにならないとは言っていない。<br>\r\nただ、過去の記憶に基づいて生み出した好感は頼れないと思う。<br>\r\nたとえ自分が昔の自分まんまと信じて言っても、<br>\r\n相手の事や、気持ちや変わってないという保障が何処にもないです。<br>\r\nそれに、ぜんぜん変わらない人などこの世には存在いないのだ。<br>\r\nそんな仮説はただの自己満足しかない。<br>\r\n\r\n一目ぼれがあるとしても、長い関係を維持するために、お互いの事を分かり合うのは一番重大な課題。<br>\r\nそれは、時間、空間、理解、寛容、信頼…いろいろなものを点から線に繋げ、作り出した物です。<br>\r\nけして、簡単な事ではありません。<br>\r\n\r\n誰でも過去には戻れない。<br>\r\n例え記憶はどんだけ暖かくでも、どんだけ懐かしくでも、過ぎだ日々はもう二度と帰れない。<br>\r\n私は十五歳の私の事が好きです。<br>\r\nある人の事を一生懸命求めってる自分の姿がとても偉いと思います。<br>\r\nそして、絶対後悔していない。<br>\r\nでも、好きというのは、そういう自分になりたいわけじゃない。<br>\r\n過去の自分だけじゃなく、私は今の自分もとても好きだ。<br>\r\nあの時から、七年の時間を経って、踏ん張って、ひたすら前に進めて、ようやく今の自分になったから――好きじゃないはずもない。<br>\r\n\r\nだから、たとえ心の底からあの過ぎた温もりに対してまだ未練があるとしても、私はそれは偽りの泡のような幻想だと思う。<br>\r\n夢は何時だって人に泣かせるほど美しい。<br>\r\nしかし、夢が夢である限り、いずれ目を覚ます。<br>\r\nそれをちゃんと認識しないと、私達は何時でも一人前とは言えない。<br>\r\n時間という物は、誰に対しても公平です。<br>\r\n瞬く間に、私達はもう大人になった。<br>\r\nそれは真の「現実」。<br>', '2020-09-17 13:35:41', 'Original', 'https://unsplash.it/800/450?image=1005', '', '', '', '過去と現実', '2020-09-17 21:55:11', '3', '1', '1', '誰でも過去には戻れない。\r\n例え記憶はどんだけ暖かくでも、どんだけ懐かしくでも、過ぎだ日々はもう二度と帰れない。\r\n私は十五歳の私の事が好きです。');
INSERT INTO t_blog VALUES ('19', '', '', '言葉の中で力があるという事、私でも分かる。<br>\r\n だが、それでもどうしても納得できない事がある。<br>\r\n 本当に言葉があるなら良いですか？<br>\r\n言葉を使えて、他人に聴きたい事だけを言って、それは、お互い幸せになれるでしょうか？<br>\r\n私なら言う――“それは違う”と。<br>\r\nせめて、私は絶対に信じられない！<br>\r\n\r\n多分、言葉は世界中で一番重い物、そして、ある時、最も安い物！<br>\r\n言葉があるこそ“約束”がある、“約束”があるから“裏切る”が居る。<br>\r\n“約束”は他人に対して“信じられないけど信じて欲しい”の証、“裏切る”のは“その約束”が昔存在したあったという事の印。<br>\r\n私たち人間、ずっと“永遠”を求めている。<br>\r\nでも、“約束”がある限り絶対一生辿り着かない。\r\n\r\n言葉を聴く時だんだん真実を見失う、言葉を使える間にどんどん本心を失くし<br>\r\nそれでも、人にとって、言葉の内容はその人の本心よりもっと大切なんですか？<br>\r\n私なら言う――“それは違う”と。<br>\r\nせめて、私はどうしても認めない！<br>\r\n\r\n“何も言えないなら、相手も分からないでしょう？”と聴いたら。<br>\r\n“そうかもしれません”と答えだ。<br>\r\nでも、相手に話したら、本当に分かり合え出来るでしょうか？<br>\r\n\r\n確かに、時は言えないなら何も始まらない。<br>\r\nでも、“貴方”と私はそういう関係なんですか？<br>\r\nはっきり言えないと、何も感じないですか？<br>\r\nそれは、本当の“大切”なんですか？<br>\r\n私なら言う――“それは違う”と！<br>\r\nせめて、私は私なりのやり方で、死んでも言えません！<br>\r\n\r\n大切だからこそ、相手の理解が欲しい！<br>\r\nしかし、理解というのは、聴きたい話を話すということではありませんと思う。<br>\r\n大切だからこそ、どうしても言えない時もある。<br>\r\n“愛は言葉で表現するものではない、心を含めて行動することだた！”<br>\r\n……と言いたいけど、多分それも私の頑固だけかもしれない。<br>\r\n\r\n人はどうしてこの世で生まれだっただろう？<br>\r\n他人に幸せを与えるためじゃないですか？<br>\r\nそれなら、どうして…どうして争いが起こる？どうして他人を傷つける？<br>\r\n\r\nそうだ、言葉の力、一番表現する場所は善意な所ではない、“悪意”なのだ！<br>\r\n誓ったのに、結局、自分の手でこの約束を潰した。<br>\r\n親しいのに、相手の欠点を見る時、どうしても我慢できない状況になった。<br>\r\n\r\n私は、恐い。<br>\r\n“言葉”を恐い。<br>\r\n本心を言いたくないほど…恐い。<br>\r\n\r\n本心を示すれば何時自分自身でこの気持ちを壊すかもしれない。<br>\r\nその時、自分はどうすればいいのかが分からない！そして、絶対に許されないだろう！<br>\r\nだから、言えないだ。死んでも、言えないだ！<br>\r\n\r\nそうだ、私は弱かった。<br>\r\n弱いから…恐いんだ！<br>\r\nでも、それでも、私はきっと、何も変わらない――変わりたくない！<br>\r\n\r\n“言葉”の重さを知ってる限り、私はだった現実的な事を言う、現実的な行動を取る。<br>\r\n誰か、どう思うとか関係ない――それは、私の生き方なのだ！<br>', '2020-09-17 13:38:31', 'Original', 'https://unsplash.it/800/450?image=1005', '', '', '', '言葉', '2020-09-17 21:55:18', '2', '1', '1', '“言葉”の重さを知ってる限り、私はだった現実的な事を言う、現実的な行動を取る。\r\n誰か、どう思うとか関係ない――それは、私の生き方なのだ！');
INSERT INTO t_blog VALUES ('20', '', '', 'SIAMO soli nell’universo? Di recente uno studio statistico italiano pubblicato su Pnas ha stimato quanti potrebbero essere gli esopianeti che ospitano la vita all’interno della nostra galassia, a patto che nei prossimi anni se ne trovi almeno uno con evidenti segni di attività biologica. Difficile sperare di trasferircisi in tempi ragionevoli, spiegava l’astrofisico Amedeo Balbi dell’università Tor Vergata di Roma che lo ha firmato insieme a Claudio Grimaldi dell’Ecole Polytechnique di Losanna. Adesso un’altra indagine, ovviamente di tipo diverso (punta esclusivamente all’identificazione del corpo celeste e non può portare prove di tracce di vita) ha confermato l’esistenza di altri 50 pianeti grazie all’aiuto di un nuovo algoritmo di machine learning.\r\n\r\nSviluppato dall’università britannica di Warwick, l’algoritmo ha per la prima volta analizzato un dataset di dati e immagini relativi a potenziali pianeti individuati tramite missioni passate o avvistamenti telescopici, determinando quali possano effettivamente corrispondere a pianeti veri e propri e quali siano invece “falsi positivi” o corpi celesti di altro genere. Calcolando così la probabilità di ogni candidato di poter essere effettivamente classificato come esopianeta a pieno titolo.\r\n \r\nI risultati, illustrati in uno studio pubblicato su Monthly Notices of the Royal Astronomical Sociey, ha messo a confronto diverse tecniche di validazione per l’analisi dei dati, includendo appunto il nuovo algoritmo “astronomico”. E si è poi messo alla prova su un corpus di “vecchi” dati della Nasa dai quali non era chiaro se certi segnali potessero effettivamente riferirsi a pianeti non appartenenti al nostro Sistema solare ma pur sempre nella Via Lattea, la galassia a cui appartiene. Quando gli scienziati sono alla ricerca di questo genere di pianeti extrasolari vanno infatti alla ricerca di “buchi” o flessioni nella luce visibile delle stelle che potrebbero appunto indicare il transito di un corpo celeste fra il telescopio e l’astro intorno al quale orbitano. Il punto è che questi segnali potrebbero essere il frutto di altri fattori legati a elementi cosmici – magari si tratta di un sistema stellare formato da due stelle - come alle stesse strumentazioni.\r\n\r\nIl nuovo sistema messo a punto dal dipartimento di Fisica e informatica dell’ateneo di Warwick e dall’Alan Turing Institute interviene proprio in questo delicato passaggio. È stato anzitutto “addestrato” su due ampi data set raccolti dall’ormai pensionata missione Kepler, chiusa nel 2018, e dal telescopio spaziale omonimo lanciato nel 2009 proprio per la ricerca e conferma di pianeti simili alla Terra in orbita attorno a stelle diverse dal Sole: si trattava di informazioni già validate contenenti pianeti confermati e falsi positivi. Due data set perfetti per allenare l’algoritmo.\r\n \r\nDopodiché, una volta pronto a lavorare da solo, il meccanismo è stato messo al lavoro su altri data set molto più incerti, tutti ancora da confermare, ricavati sempre dalle stesse osservazioni accumulate da Kepler in quasi dieci anni di onorato servizio. In questa prova, spiegata nello studio, ha attribuito un’elevata probabilità a cinquanta esopianeti estremamente diversi per dimensioni (ce ne sono di grandi come il gigante gassoso Nettuno o più piccoli come la Terra) e per molti altri fattori come la durata delle loro orbite intorno alle rispettive stelle, che variano da un giorno a 200 giorni terrestri. Il punto è che, indirizzati dall’intelligenza artificiale, gli esperti possono ora concentrarsi nell’osservazione, dando priorità ai pianeti identificati dall’algoritmo e scegliendo i telescopi e le informazioni più adeguati.\r\n\r\n“Precedenti tecniche di machine learning erano state in grado di classificare i candidati – si legge in una nota dell’università britannica – ma non avevano mai determinato da sole la probabilità che un candidato fosse un vero pianeta, che è appunto un passaggio essenziale per la validazione”. In particolare, “speriamo di utilizzare questa tecnica a più ampi campioni di candidati raccolti dalle attuali e future missioni come Tess e Plato” ha spiegato David Armstrong del dipartimento di Fisica. Si riferisce nel primo caso al Transiting Exoplanet Survey Satellite, il telescopio spaziale lanciato due anni fa nell’ambito del programma Explorer della Nasa che ha scoperto 67 esopianeti e ha individuato per la precisione 2.174 candidati. Fra i primi, fra l’altro, c’è anche un pianeta che – come Tatooine in \"Star Wars\" – orbita intorno a due Soli: è quello che orbita intorno alla stella binaria TOI-1338b e si trova nella costellazione del Pittore a 1.300 anni luce dal Sistema solare. Ad accorgersi di esso è stato lo scorso anno uno stagista estivo del Goddard Space Flight Center della Nasa del Maryland, il 17enne Wwolf Cukier. Una mole abominevole, com’è evidente, che un sistema come quello britannico promette di “filtrare” con più facilità.\r\n\r\nNel secondo caso, invece, l’esperto si riferisce a Plato, che sta per “PLAnetary Transits and Oscillations of stars” ed è un telescopio spaziale (anzi, un satellite munito di 26 piccoli telescopi) in fase di progettazione da parte dell’Agenzia spaziale europea proprio per lo studio di pianeti extrasolari tramite il metodo fotometrico del transito. Non dovrebbe decollare prima dei prossimi sei anni: aprirà la strada alle altre missioni come Ariel, nel 2028, per lo studio delle atmosfere dei pianeti in orbita intorno a stelle distanti, e Athena, nel 2030, il grande osservatorio spaziale in raggi X.\r\n \r\n“In termini di validazione dei pianeti, nessun ha utilizzato la tecnica del machine learning prima d’ora – ha aggiunto Armstrong – sfruttata nella classificazione, non è mai stata applicata a calcoli probabilistici, che è poi ciò di cui abbiamo effettivamente bisogno per validare davvero un pianeta. Invece di dire quali candidati potrebbero essere dei pianeti, ora possiamo affermare qual è la probabilità precisa. Dove si verifica una possibilità di falso positivo minore dell’1%, allora si è di fronte a un pianeta confermato”. Un fronte di assoluto interesse per l’approccio probabilistico del machine learning statistico quello astronomico, che deve tenere presenti conoscenze pregresse e quantificazione di incertezza nelle previsioni, ha aggiunto Theo Damoulas del dipartimento di Informatica e Turing Fellow all’Alan Turing Institute.\r\n \r\nUna volta costruito e addestrato, insomma, l’algoritmo passa da solo al setaccio quantità infinite di dati raccolti dai telescopi, analizzando migliaia di potenziali pianeti. E secondo i ricercatori dovrebbe diventare il metodo standard per procedere in questo ambito o almeno da associare ad altre analisi. “Quasi il 30% dei pianeti conosciuti sono stati validati utilizzando solo un metodo, e questo non è il percorso ideale – ha spiegato Armstrong – sviluppare nuovi metodi è giusto solo per questo. Ma il machine learning ci consente anche di farlo molto rapidamente e di dare dunque priorità ai candidati con più rapidità”.', '2020-09-17 13:41:31', 'Reprint', 'https://unsplash.it/800/450?image=227', '', '', '', 'Se l\'Ai scopre 50 nuovi pianeti scavando nei dati della Nasa', '2020-09-17 13:41:31', '0', '3', '1', 'SIAMO soli nell’universo? Di recente uno studio statistico italiano pubblicato su Pnas ha stimato quanti potrebbero essere gli esopianeti che ospitano la vita all’interno della nostra galassia, a patt');
INSERT INTO t_blog VALUES ('21', '', '', 'TORINO. Per rendere l’idea del fenomeno basta pensare agli abitanti di una città delle dimensioni di Alessandria. Secondo Cgil, Cisl e Uil - oggi in piazza per la Vertenza Torino - in Piemonte da inizio gennaio gli avviamenti al lavoro sono stati 92 mila in meno rispetto a un anno (-26%). Colpa della pandemia, certo, ma anche di un sistema di politiche attive che per il segretario generale della Uil Piemonte, Gianni Cortese, è pieno di carenze «soprattutto rispetto alla capacità di intercettare l’incrocio tra domanda e offerta di competenze». \r\n\r\nLa materia è complessa, spiega Cortese, «anche perché si lega a un tema che, oltre alla formazione, riguarda la gestione degli ammortizzatori sociali e politiche come il reddito di cittadinanza». Il problema, per il sindacalista, non è da ricercarsi nella mancanza di formazione «ma nella carenza di buona formazione». «Se chi fa le politiche attive non ha chiare quali sono le figure più ricercate - dice - è scontato che il sistema si inceppi». Quel che serve, secondo il leader della Uil, «è un censimento della domanda».\r\n<br>\r\nVa detto che qualcosa sul territorio si muove. Il 2 ottobre partirà la prima edizione della Competence Industry Manufacturing 4.0 Academy, una struttura di formazione continua per preparare responsabili di area tecnica, manager, imprenditori e lavoratori o professionisti in cerca di ricollocamento. L’apprendistato e la formazione continua a domanda individuale sono autorizzati a ripartire. Mentre la formazione legata al mercato del lavoro, quindi quella che riguarda i lavoratori occupati, la qualificazione e riqualificazione e l’inserimento dei giovani inoccupati o disoccupati è legata alla reiterazione di un bando e si aspetta l’autorizzazione dalla Regione. Un impegno che prima si aggirava sui 40 milioni all’anno e che ora si auspica venga incrementato. «Il nuovo bando che in teoria dovrebbe partire alla fine di settembre non è stato emesso e questa è una fonte di preoccupazione. Per i lavoratori è un handicap perché se prima era uno strumento utile, ora diventa indispensabile», spiega Sigfrido Pilone, direttore Assocam Scuola Camerana.\r\n\r\nPositivo, invece, il bilancio per la formazione professionalizzante Its. Il 30 luglio la Fondazione ITS Aerospazio e Meccatronica del Piemonte ha diplomato 105 ragazzi e il 79% ha concluso il percorso con un contratto di lavoro mantenendo i trend medi dell’ultimo quinquennio (98% di occupazione dei diplomati a 12 mesi dal titolo). «È vero, ci potranno essere licenziamenti ma dal nostro punto di vista siamo fiduciosi, ci sarà anche turnover», conclude Stefano Serra , presidente della Fondazione e vice presidente Amma. —', '2020-09-17 13:42:54', 'Reprint', 'https://unsplash.it/800/450?image=227', '', '', '', 'In Piemonte persi 92 mila posti di lavoro, i sindacati in piazza a Torino', '2020-09-17 16:20:16', '1', '3', '1', 'Si spera nel bando regionale. E’ positivo invece il bilancio per la formazione professionale');

-- ----------------------------
-- Table structure for `t_blog_tags`
-- ----------------------------
DROP TABLE IF EXISTS `t_blog_tags`;
CREATE TABLE `t_blog_tags` (
  `blogs_id` bigint(20) NOT NULL,
  `tags_id` bigint(20) NOT NULL,
  KEY `FK5feau0gb4lq47fdb03uboswm8` (`tags_id`),
  KEY `FKh4pacwjwofrugxa9hpwaxg6mr` (`blogs_id`),
  CONSTRAINT `FKh4pacwjwofrugxa9hpwaxg6mr` FOREIGN KEY (`blogs_id`) REFERENCES `t_blog` (`id`),
  CONSTRAINT `FK5feau0gb4lq47fdb03uboswm8` FOREIGN KEY (`tags_id`) REFERENCES `t_tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_blog_tags
-- ----------------------------
INSERT INTO t_blog_tags VALUES ('13', '14');
INSERT INTO t_blog_tags VALUES ('16', '17');
INSERT INTO t_blog_tags VALUES ('15', '17');
INSERT INTO t_blog_tags VALUES ('20', '17');
INSERT INTO t_blog_tags VALUES ('21', '17');
INSERT INTO t_blog_tags VALUES ('18', '5');
INSERT INTO t_blog_tags VALUES ('18', '22');
INSERT INTO t_blog_tags VALUES ('19', '5');
INSERT INTO t_blog_tags VALUES ('11', '5');
INSERT INTO t_blog_tags VALUES ('11', '22');

-- ----------------------------
-- Table structure for `t_category`
-- ----------------------------
DROP TABLE IF EXISTS `t_category`;
CREATE TABLE `t_category` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_category
-- ----------------------------
INSERT INTO t_category VALUES ('1', 'Fan Fiction');
INSERT INTO t_category VALUES ('2', 'Java');
INSERT INTO t_category VALUES ('3', 'Essay');
INSERT INTO t_category VALUES ('12', 'Music');

-- ----------------------------
-- Table structure for `t_comment`
-- ----------------------------
DROP TABLE IF EXISTS `t_comment`;
CREATE TABLE `t_comment` (
  `id` bigint(20) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `blog_id` bigint(20) DEFAULT NULL,
  `parent_comment_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKke3uogd04j4jx316m1p51e05u` (`blog_id`),
  KEY `FK4jj284r3pb7japogvo6h72q95` (`parent_comment_id`),
  CONSTRAINT `FK4jj284r3pb7japogvo6h72q95` FOREIGN KEY (`parent_comment_id`) REFERENCES `t_comment` (`id`),
  CONSTRAINT `FKke3uogd04j4jx316m1p51e05u` FOREIGN KEY (`blog_id`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_comment
-- ----------------------------

-- ----------------------------
-- Table structure for `t_tag`
-- ----------------------------
DROP TABLE IF EXISTS `t_tag`;
CREATE TABLE `t_tag` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_tag
-- ----------------------------
INSERT INTO t_tag VALUES ('5', 'SLAM DUNK');
INSERT INTO t_tag VALUES ('6', 'One Piece');
INSERT INTO t_tag VALUES ('7', 'Naruto');
INSERT INTO t_tag VALUES ('14', 'Java8');
INSERT INTO t_tag VALUES ('17', 'News');
INSERT INTO t_tag VALUES ('22', 'Life');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO t_user VALUES ('1', 'https://unsplash.it/100/100?image=1005', null, null, 'root', 'e10adc3949ba59abbe56e057f20f883e', null, null, 'root');
