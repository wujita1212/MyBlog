package com.wujita.myblog.web.admin;

import com.wujita.myblog.entity.Category;
import com.wujita.myblog.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * @author wujita
 * @create 2020-09-12-4:22 pm
 */
@Controller
@RequestMapping("/admin")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/category")
    public String category(@PageableDefault(size = 10, sort={"id"}, direction = Sort.Direction.DESC) Pageable pageable, Model model){
        model.addAttribute("page",categoryService.listCategory(pageable));
        return "admin/category";
    }

    @GetMapping("/category/input")
    public String input(Model model){
        model.addAttribute("category",new Category());
        return"admin/category-input";
    }

    @GetMapping("/category/{id}/input")
    public String editInput(@PathVariable Long id, Model model){
        model.addAttribute("category",categoryService.getCategory(id));
        return "admin/category-input";
    }

    @PostMapping("/category")
    public String post(Category category, BindingResult result, RedirectAttributes attributes){
        Category c = categoryService.getCategoryByName(category.getName());
        if(c != null){ //category名字不能重复
            result.rejectValue("name","nameError","Category repeated");
        }
        if(result.hasErrors()){
            return"admin/category-input";
        }
        Category cate = categoryService.saveCategory(category);
        if(cate != null){
            attributes.addFlashAttribute("message","Add Success");
        }
        else{
            attributes.addFlashAttribute("message","Add fail");
        }
        return "redirect:/admin/category";
    }

    @PostMapping("/category/{id}")
    //注意在传参是Category category和BindingResult必须紧挨在一起
    public String editPost(Category category, BindingResult result, @PathVariable Long id, RedirectAttributes attributes){
//        Category c = categoryService.getCategoryByName(category.getName());
//        if(c != null){ //category名字不能重复
//            result.rejectValue("name","nameError","Category repeated");
//        }
//        if(result.hasErrors()){
//            return"admin/category-input";
//        }
        Category cate = categoryService.updateCategory(id,category);
        if(cate != null){
            attributes.addFlashAttribute("message","Update Success");
        }
        else{
            attributes.addFlashAttribute("message","Update fail");
        }
        return "redirect:/admin/category";
    }

    @GetMapping("/category/{id}/delete")
    public String delete(@PathVariable Long id,RedirectAttributes attributes){
        categoryService.deleteCategory(id);
        attributes.addFlashAttribute("message","delete success");
        return "redirect:/admin/category";
    }
}
