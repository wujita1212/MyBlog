package com.wujita.myblog;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author wujita
 * @create 2020-09-11-6:10 pm
 */

@ResponseStatus(HttpStatus.NOT_FOUND)
//如果要指定返回的页面，必须加上注解@RpesonseStatus
//后续参数表示当错误为NotFoundException时，最终状态将视为无法找到资源
//达能springboot获取状态为NOT_FOUND，即会跳转至对应错误资源404
public class NotFoundException extends RuntimeException{

    public NotFoundException() {
    }

    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
