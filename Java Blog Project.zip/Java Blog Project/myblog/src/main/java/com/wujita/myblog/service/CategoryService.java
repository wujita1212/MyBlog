package com.wujita.myblog.service;

import com.wujita.myblog.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author wujita
 * @create 2020-09-12-4:07 pm
 */
public interface CategoryService {

    public Category saveCategory(Category category);

    public Category getCategory(Long id);

    public Page<Category> listCategory(Pageable pageable);

    public List<Category> listCategory();

    public List<Category> listCategoryTop(Integer size);

    public Category updateCategory(Long id, Category category);

    public void deleteCategory(Long id);

    public Category getCategoryByName(String name);
}
