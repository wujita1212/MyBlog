package com.wujita.myblog.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

/**
 * @author wujita
 * @create 2020-09-11-6:41 pm
 */
@Aspect
@Component
public class LogAspect {

    //获取日志记录器
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Pointcut("execution(* com.wujita.myblog.web.*.*(..))")
    //通过@Pointcut申明这是一个切面，而execution中的内容用于规定这个切面用于拦截哪些类
    //com.wujita.myblog.web.*.*()指的是web包下所有的类对应的所有方法
    public void log(){
    }

    @Before("log()")
    //只要有请求发过来，都会在返回前执行doBefore()
    public void doBefore(JoinPoint joinPoint){
        //获取httpRequest以获取url和ip的具体值
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String url = request.getRequestURL().toString();
        String ip = request.getRemoteAddr();
        //获取切面对应的拦截包下的拦截方法（所有方法）
        String classMethod = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();
        //创建对象
        RequestLog requestLog = new RequestLog(url, ip, classMethod, args);
        //输出信息
        logger.info("Request:{}",requestLog);
    }

    @After("log()")
    public void doAfter(){
        //logger.info("-------doAfter-------");
    }

    @AfterReturning(returning = "result",pointcut = "log()")
    public void doAfterReturn(Object result){
        logger.info("Result:{}", result);
    }

    private class RequestLog{
        private String url;
        private String ip;
        private String classMethod;
        private Object[] args;

        public RequestLog(String url, String ip, String classMethod, Object[] args) {
            this.url = url;
            this.ip = ip;
            this.classMethod = classMethod;
            this.args = args;
        }

        @Override
        public String toString() {
            return "RequestLog{" +
                    "url='" + url + '\'' +
                    ", ip='" + ip + '\'' +
                    ", classMethod='" + classMethod + '\'' +
                    ", args=" + Arrays.toString(args) +
                    '}';
        }
    }
}
