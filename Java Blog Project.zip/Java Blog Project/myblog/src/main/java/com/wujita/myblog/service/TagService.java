package com.wujita.myblog.service;

import com.wujita.myblog.entity.Category;
import com.wujita.myblog.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author wujita
 * @create 2020-09-12-4:07 pm
 */
public interface TagService {

    public Tag saveTag(Tag tag);

    public Tag getTag(Long id);

    public Page<Tag> listTag(Pageable pageable);

    public List<Tag> listTag();

    public List<Tag> listTagTop(Integer size);

    public List<Tag> listTag(String ids);

    public Tag updateTag(Long id, Tag tag);

    public void deleteTag(Long id);

    public Tag getTagByName(String name);
}
