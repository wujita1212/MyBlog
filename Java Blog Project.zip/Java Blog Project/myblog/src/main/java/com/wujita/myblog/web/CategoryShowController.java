package com.wujita.myblog.web;

import com.wujita.myblog.entity.Category;
import com.wujita.myblog.service.BlogService;
import com.wujita.myblog.service.CategoryService;
import com.wujita.myblog.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * @author wujita
 * @create 2020-09-17-9:15 pm
 */
@Controller
public class CategoryShowController {

    @Autowired
    private BlogService blogService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/category/{id}")
    public String category(@PageableDefault(size=8,sort={"updateTime"},direction = Sort.Direction.DESC) Pageable pageable, @PathVariable Long id, Model model){
        List<Category> category = categoryService.listCategoryTop(10000);
        if (id == -1) {
            id = category.get(0).getId();
        }
        BlogQuery blogQuery = new BlogQuery();
        blogQuery.setCategoryId(id);
        model.addAttribute("category",category);
        model.addAttribute("page",blogService.listBlog(pageable,blogQuery));
        model.addAttribute("activeCategoryId",id);
        return "sort";
    }
}
