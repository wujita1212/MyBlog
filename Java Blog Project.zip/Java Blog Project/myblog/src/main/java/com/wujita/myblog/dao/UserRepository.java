package com.wujita.myblog.dao;

import com.wujita.myblog.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author wujita
 * @create 2020-09-12-1:56 am
 */
public interface UserRepository extends JpaRepository<User,Long> {
    //当继承了JpaRepository并将对象设为User，主键类型设为Long后
    //我们就可以直接调用数据库中对应的增删改查方法，无需自己设计
    public User findByUsernameAndPassword(String username,String password);

}
