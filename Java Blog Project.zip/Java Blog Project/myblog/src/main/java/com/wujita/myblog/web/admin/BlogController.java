package com.wujita.myblog.web.admin;

import com.wujita.myblog.entity.Blog;
import com.wujita.myblog.entity.User;
import com.wujita.myblog.service.BlogService;
import com.wujita.myblog.service.CategoryService;
import com.wujita.myblog.service.TagService;
import com.wujita.myblog.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;

/**
 * @author wujita
 * @create 2020-09-12-3:20 am
 */
@Controller
@RequestMapping("/admin")
public class BlogController {

    private static final String INPUT = "admin/release";
    private static final String LIST = "admin/blog";
    private static final String REDIRECT_LIST = "redirect:/admin/blog";


    @Autowired
    private BlogService blogService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private TagService tagService;

    @GetMapping("/blog")
    public String blog(@PageableDefault(size = 2, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable,
                       BlogQuery blog, Model model)  {
        model.addAttribute("category", categoryService.listCategory());
        model.addAttribute("page", blogService.listBlog(pageable, blog));
        return LIST;
    }

    @PostMapping("/blog/search")
    public String search(@PageableDefault(size = 8, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable,
                         BlogQuery blog, Model model) {
        model.addAttribute("page", blogService.listBlog(pageable, blog));
        return "admin/blog :: blogList";
    }
        //返回admin/blog页面下的blogList这个片段，实现局部渲染

    @GetMapping("/blog/publish")
    public String input(Model model){
        model.addAttribute("category",categoryService.listCategory());
        model.addAttribute("tag",tagService.listTag());
        model.addAttribute("blog",new Blog());
        return INPUT;
    }

    @GetMapping("/blog/{id}/publish")
    public String editInput(@PathVariable Long id, Model model){
        model.addAttribute("category", categoryService.listCategory());
        model.addAttribute("tag", tagService.listTag());
        Blog blog = blogService.getBlog(id);
        blog.init();
        model.addAttribute("blog",blog);
        return INPUT;
    }

    @PostMapping("/blog")
    public String post(Blog blog, RedirectAttributes attributes,HttpSession session){
        blog.setUser((User) session.getAttribute("user"));
        blog.setCategory(categoryService.getCategory(blog.getCategory().getId()));
        blog.setTags(tagService.listTag(blog.getTagIds()));
        Blog b;
        if (blog.getId() == null) {
            b =  blogService.saveBlog(blog);
        } else {
            b = blogService.updateBlog(blog.getId(), blog);
        }
        if(b != null){
            attributes.addFlashAttribute("message","Operation Success");
        }
        else{
            attributes.addFlashAttribute("message","Operation Fail");
        }
        return REDIRECT_LIST;
    }

    @GetMapping("/blog/{id}/delete")
    public String delete(@PathVariable Long id,RedirectAttributes attributes){
        blogService.deleteBlog(id);
        attributes.addFlashAttribute("message","delete success");
        return "redirect:/admin/blog";
    }
}
