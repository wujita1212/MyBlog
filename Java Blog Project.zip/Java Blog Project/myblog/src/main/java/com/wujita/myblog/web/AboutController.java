package com.wujita.myblog.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author wujita
 * @create 2020-09-18-12:03 am
 */
@Controller
public class AboutController {
    @GetMapping("/about")
    public String about() {
        return "about me";
    }
}
