package com.wujita.myblog.service;

import com.wujita.myblog.NotFoundException;
import com.wujita.myblog.dao.CategoryRepository;
import com.wujita.myblog.entity.Category;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wujita
 * @create 2020-09-12-4:10 pm
 */
@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public Category saveCategory(Category category) {
        return categoryRepository.save(category);
    }

    @Override
    public Category getCategory(Long id) {
        return categoryRepository.findById(id).get();
    }

    @Override
    public Page<Category> listCategory(Pageable pageable) {
        return categoryRepository.findAll(pageable);
    }

    @Override
    public List<Category> listCategory() {
        return categoryRepository.findAll();
    }

    @Override
    public List<Category> listCategoryTop(Integer size) {
        Sort sort = Sort.by(Sort.Order.desc("blogs.size"));
        //该blogs是Category类中的blogs
        Pageable pageable =PageRequest.of(0, size, sort);
        return categoryRepository.findTop(pageable);
    }

    @Override
    public Category updateCategory(Long id, Category category) {
        Category cate = categoryRepository.findById(id).get();
        if(cate == null){
            throw new NotFoundException("this category not exists");
        }
        BeanUtils.copyProperties(category,cate);
        return categoryRepository.save(cate);
    }

    @Override
    public void deleteCategory(Long id) {
        categoryRepository.deleteById(id);
    }

    @Override
    public Category getCategoryByName(String name) {
        return categoryRepository.findByName(name);
    }
}
