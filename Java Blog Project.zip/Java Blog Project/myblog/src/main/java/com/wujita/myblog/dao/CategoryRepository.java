package com.wujita.myblog.dao;

import com.wujita.myblog.entity.Category;
import com.wujita.myblog.entity.User;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author wujita
 * @create 2020-09-12-4:11 pm
 */
public interface CategoryRepository extends JpaRepository<Category,Long> {

    Category findByName(String name);

    @Query("select c from Category c") //进行查询
    List<Category> findTop(Pageable pageable);
}
