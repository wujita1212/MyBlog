package com.wujita.myblog.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * 拦截器
 * 在没有特别条件分化时，所有@Controller类发生异常都会跳转至error页面
 * 如果此时，我们希望它跳转至其他页面（如NotFoundExecption跳至404）
 * 需要在代码中增加条件判断语句
 * 也就是，当有些Exception异常标识了状态码时，该拦截器就不起作用
 * 交给springboot自己去进行处理
 * @author wujita
 * @create 2020-09-11-5:49 pm
 */
@ControllerAdvice
//拦截所有包含controller注解的控制器
public class ControllerExceptionHandler {

    //获取日志信息
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler(Exception.class)
    //表示该方法可以用于异常处理
    //只要改异常信息属于Exception类，即调用该方法
    public ModelAndView exceptionHander(HttpServletRequest request, Exception e) throws Exception {
        //记录异常信息，包括：URL，Exception具体内容
        logger.error("Request URL:{},Exception:{}",request.getRequestURL(),e);

        //判断异常是否有状态码，如果有执行springboot自带异常处理
        //如果没有状态码，开始准备跳转error.html页面
        if(AnnotationUtils.findAnnotation(e.getClass(), ResponseStatus.class) != null){
            throw e;
        }
        //由于需要返回的是一个MAV页面，因此我们先要创建一个MAV对象
        ModelAndView mv = new ModelAndView();
        //该页面中需要包含URL和Exception对应信息
        mv.addObject("url",request.getRequestURL());
        mv.addObject("exception",e);
        //设定对应信息需要返回到的页面的路径和名称
        mv.setViewName("error/error");
        return mv;
    }
}
