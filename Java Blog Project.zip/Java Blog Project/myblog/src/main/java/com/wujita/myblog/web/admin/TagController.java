package com.wujita.myblog.web.admin;

import com.wujita.myblog.entity.Tag;
import com.wujita.myblog.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * @author wujita
 * @create 2020-09-12-4:22 pm
 */
@Controller
@RequestMapping("/admin")
public class TagController {

    @Autowired
    private TagService tagService;

    @GetMapping("/tag")
    public String tag(@PageableDefault(size = 10, sort={"id"}, direction = Sort.Direction.DESC) Pageable pageable, Model model){
        model.addAttribute("page",tagService.listTag(pageable));
        return "admin/tag";
    }

    @GetMapping("/tag/input")
    public String input(Model model){
        model.addAttribute("tag",new Tag());
        return"admin/tag-input";
    }

    @GetMapping("/tag/{id}/input")
    public String editInput(@PathVariable Long id, Model model){
        model.addAttribute("tag",tagService.getTag(id));
        return "admin/tag-input";
    }

    @PostMapping("/tag")
    public String post(Tag tag, BindingResult result, RedirectAttributes attributes){
        Tag t = tagService.getTagByName(tag.getName());
        if(t != null){ //category名字不能重复
            result.rejectValue("name","nameError","Tag repeated");
        }
        if(result.hasErrors()){
            return"admin/tag-input";
        }
        Tag ta = tagService.saveTag(tag);
        if(ta != null){
            attributes.addFlashAttribute("message","Add Success");
        }
        else{
            attributes.addFlashAttribute("message","Add fail");
        }
        return "redirect:/admin/tag";
    }

    @PostMapping("/tag/{id}")
    public String editPost(Tag tag, BindingResult result, @PathVariable Long id, RedirectAttributes attributes){

        Tag t = tagService.updateTag(id,tag);
        if(t != null){
            attributes.addFlashAttribute("message","Update Success");
        }
        else{
            attributes.addFlashAttribute("message","Update fail");
        }
        return "redirect:/admin/tag";
    }

    @GetMapping("/tag/{id}/delete")
    public String delete(@PathVariable Long id,RedirectAttributes attributes){
        tagService.deleteTag(id);
        attributes.addFlashAttribute("message","delete success");
        return "redirect:/admin/tag";
    }
}
