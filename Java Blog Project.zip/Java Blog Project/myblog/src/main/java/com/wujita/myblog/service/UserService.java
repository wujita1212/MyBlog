package com.wujita.myblog.service;

import com.wujita.myblog.entity.User;

/**
 * @author wujita
 * @create 2020-09-12-1:53 am
 */
public interface UserService {

    public User checkUser(String username,String password);
}
