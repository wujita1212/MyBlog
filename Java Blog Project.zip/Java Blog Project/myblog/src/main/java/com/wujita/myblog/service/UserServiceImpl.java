package com.wujita.myblog.service;

import com.wujita.myblog.dao.UserRepository;
import com.wujita.myblog.entity.User;
import com.wujita.myblog.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author wujita
 * @create 2020-09-12-1:54 am
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    @Override
    public User checkUser(String username, String password) {
        User user = userRepository.findByUsernameAndPassword(username, MD5Utils.code(password));
        return user;
    }
}
